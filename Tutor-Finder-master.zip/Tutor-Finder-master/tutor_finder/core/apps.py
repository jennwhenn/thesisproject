'''
Auto generated file

Do not edit
'''

from django.apps import AppConfig

class CoreConfig(AppConfig):
    '''Auto-generated'''
    name = 'core'
