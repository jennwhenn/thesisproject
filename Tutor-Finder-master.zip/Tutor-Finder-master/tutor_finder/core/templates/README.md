HTML/MARKUP template directory

Django Specifies that templates be stored in directory labeled as such

Each html template renders a form/page/markup, typically labeled as the end of the url to be displayed by the page

the /registration subdirectory holds the templates generated to handle signup, form submission, authentication, storage, and security
form user accounts

base.html is responsible for rendering the upper banner present throughout the webapp, and is inhereted by almost every html template
for in site navigation