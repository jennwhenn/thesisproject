'''
This file is designed to be a place
holder for automated tests,

At the moment our test plans have been
largely manual testing.
'''

#Never used, we use our own testing software (travis CI) and systems
#from django.test import TestCase

# Create your tests here.
